
var ENCSObject = [
20441664,
13195833,
42131275,
22105187,
83539293,
94593151,
60204553,
72162877,
61384865,
86702589,
81424734,
97287306,
91390184,
93468099,
23240344,
71353517,
53492116,
23188381,
64793158,
78263799,
93595976,
82795616,
98552865,
70809114,
90249254,
87799493,
76576759,
34227043,
31173611,
85657807,
52053838,
57323907,
69458849,
34530746,
71589078,
52815169,
29056434,
63478840,
80759413,
79684546,
66842260,
14022041,
45341643,
49240178,
77719205,
36281810,
89033050,
76341448,
29633120,
14248376,
89468164,
85905500,
27266890,
74414617,
58218456,
96883025,
72580404,
32068079,
78679606,
70303466,
22429375,
10469942,
71527122,
17263992,
88782466,
50978713,
78669367,
94025513,
25239800,
31779256,
13262990,
39052286,
92427775,
42934654,
66580707,
79209237,
65656260,
65675215,
53755664,
76685942,
92878346,
95125756,
80209410,
18300108,
96717994,
23902464,
14265312,
72175931,
39269343,
39872731,
49530312,
62217642,
80810452,
76169208,
24328783,
70467552,
56095024,
56888628,
98484839,
33724676
]



function getInfo()
{
    var studentID = document.getElementById("StudentID").value
    var password = document.getElementById("password").value
    
    for(i=0; ENCSObject.length; i++)
    {
        
        if(studentID==ENCSObject[i])
        {
            window.open("enggame.html");
            break;
        } 
        
        else
        {
            window.alert("Error! Please make sure you are a ENCS student")
            break;
        }
    
    }
    
    
}

function done()
{
    window.alert("Registered!")
}

function staff()
{
    window.open("admin.html");
}


var students=[];
var event1=[];
var event2=[];
var event3=[];


function displayStudents(){

        for (i = 0; i < students.length; i++){
        document.write("Student " + i + ":");    
        document.write("\n");
        document.write("Name: " + students[i].name + " <br> ID: " + students[i].ID +  ", Event Registered to: " + students[i].event);
        document.write("<br>");
        document.write("<br>");
    }

}

function displayStudentsOfEvent1(){
    
    for (i = 0; i < event1.length; i++){
        document.write("Student " + i + ":");    
        document.write("\n");
        document.write("<br> ID: " + event1[i].ID);
        document.write("<br>");
        document.write("<br>");
    }
    
}
    
function displayStudentsOfEvent2(){
    
    for (i = 0; i < event2.length; i++){
        document.write("Student " + i + ":");    
        document.write("\n");
        document.write("<br> ID: " + event2[i].ID);
        document.write("<br>");
        document.write("<br>");
    }
    
}

function displayStudentsOfEvent3(){
    
    for (i = 0; i < event3.length; i++){
        document.write("Student " + i + ":");    
        document.write("\n");
        document.write("<br> ID: " + event3[i].ID);
        document.write("<br>");
        document.write("<br>");
    }
    
}


function addStudents()
{
    var name = document.getElementById("name").value
    var ID = document.getElementById("ID").value
    var event = document.getElementById("event").value
    
    if(event==1)
    {
      event1.push(ID);  
      window.alert("Error! Please make sure you are a ENCS student");
    }
    
    if (event==2)
    {
        event2.push(ID);
        window.open("admin.html");
    }
    
    if(event==3)
    {
        event3.push(ID); 
        window.open("admin.html");
    }
    
    students.push(name,ID,event);
    
}